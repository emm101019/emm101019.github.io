CS 499 Milestone Three Artifact

This ZIP includes the original CS 360 Weight Tracker project and the enhanced project.

- Original_Artifact contains the original Android Studio project.
- Enhanced_Artifact contains the Milestone Two updates and the Milestone Three algorithms and data structure enhancement.
- ENHANCEMENT_ONE_README.md describes the software design and engineering changes.
- ENHANCEMENT_TWO_README.md describes the algorithms and data structure changes.

Open either M3AppEvaMacaluso folder in Android Studio. The enhanced project includes unit tests under app/src/test.
