# CS 499 Enhancement Two

This enhancement adds date-ordered weight analysis to the Weight Tracker app.

## What changed

- `WeightProgressAnalyzer` copies valid `WeightEntry` objects into an `ArrayList` and sorts them by date. Records with the same date are ordered by record ID.
- The analyzer uses a seven-entry queue and a running sum to calculate each moving average in one pass.
- It calculates total weight change, progress toward a weight-loss or weight-gain goal, and the current streak of entries moving closer to the goal.
- Invalid dates and nonpositive or non-finite weights are left out of the analysis. The dashboard tells the user when records were skipped.
- The home screen shows the summary and a chart with recorded weights and the moving average.
- Unit tests cover empty and one-entry histories, out-of-order and duplicate dates, moving averages, goal progress, improvement streaks, invalid values, and a larger history.

## Algorithm notes

Sorting costs O(n log n). The moving-average and summary pass costs O(n) time. The seven-entry window uses O(1) space. The sorted result list uses O(n) space. The rolling sum adds the new weight and removes the oldest weight when the window passes seven entries. This avoids summing the same seven values again for every chart point.

The database query already returns records in descending date order. The analyzer sorts its own copy into ascending date order so the chart, starting weight, and current weight all use the same chronological sequence. The repository's list remains unchanged.

## Tests

Run the app's unit tests in Android Studio or with `./gradlew testDebugUnitTest`.
