package com.example.m3app_evamacaluso.data;

import com.example.m3app_evamacaluso.DatabaseHelper;

/** Separates account data operations from activity and view code. */
public final class UserRepository {
    private final DatabaseHelper database;

    public UserRepository(DatabaseHelper database) {
        this.database = database;
    }

    public boolean exists(String username) {
        return database.userExists(username);
    }

    public boolean create(String username, String password) {
        return database.insertUser(username, password);
    }

    public boolean authenticate(String username, String password) {
        return database.checkLogin(username, password);
    }
}
