package com.example.m3app_evamacaluso;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.m3app_evamacaluso.data.UserRepository;
import com.example.m3app_evamacaluso.util.InputValidator;

public class MainActivity extends AppCompatActivity {

    private EditText usernameField, passwordField;
    private Button loginButton, createAccountButton;
    private UserRepository users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connect Java to XML views
        usernameField = findViewById(R.id.usernameField);
        passwordField = findViewById(R.id.passwordField);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        users = new UserRepository(new DatabaseHelper(this));

        // Create account button
        createAccountButton.setOnClickListener(v -> createAccount());

        // Login button
        loginButton.setOnClickListener(v -> logIn());
    }

    private boolean validateNewAccount(String username, String password) {
        usernameField.setError(InputValidator.usernameError(username));
        passwordField.setError(InputValidator.passwordError(password));
        return usernameField.getError() == null && passwordField.getError() == null;
    }

    private boolean validateLogin(String username, String password) {
        usernameField.setError(username.isEmpty() ? "Username is required" : null);
        passwordField.setError(password.isEmpty() ? "Password is required" : null);
        return usernameField.getError() == null && passwordField.getError() == null;
    }

    private void createAccount() {
        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString();
        if (!validateNewAccount(username, password)) {
            return;
        }
        if (users.exists(username)) {
            usernameField.setError("Username already exists");
            usernameField.requestFocus();
            return;
        }
        if (users.create(username, password)) {
            Toast.makeText(this, "Account created. You can now log in.", Toast.LENGTH_SHORT).show();
            passwordField.setText("");
        } else {
            Toast.makeText(this, "Account could not be created", Toast.LENGTH_SHORT).show();
        }
    }

    private void logIn() {
        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString();
        if (!validateLogin(username, password)) {
            return;
        }
        if (!users.authenticate(username, password)) {
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(this, HomeActivity.class);
        intent.putExtra(HomeActivity.EXTRA_USERNAME, username);
        startActivity(intent);
        finish();
    }
}
