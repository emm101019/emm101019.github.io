package com.example.m3app_evamacaluso.util;

import com.example.m3app_evamacaluso.model.WeightEntry;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.List;

/** Orders weight records and calculates a compact progress summary. */
public final class WeightProgressAnalyzer {
    private static final int MOVING_AVERAGE_WINDOW = 7;
    private static final double EPSILON = 0.0001;

    private WeightProgressAnalyzer() {
    }

    /**
     * Returns analysis in chronological order without changing the caller's list.
     * Sorting costs O(n log n); the moving-average pass costs O(n).
     */
    public static Analysis analyze(List<WeightEntry> source, Double goalWeight) {
        List<DatedEntry> validEntries = new ArrayList<>();
        int ignoredEntries = 0;

        if (source != null) {
            for (WeightEntry entry : source) {
                if (entry == null || !Double.isFinite(entry.getWeight()) || entry.getWeight() <= 0) {
                    ignoredEntries++;
                    continue;
                }
                try {
                    LocalDate date = LocalDate.parse(entry.getDate());
                    validEntries.add(new DatedEntry(entry, date));
                } catch (DateTimeParseException | NullPointerException exception) {
                    ignoredEntries++;
                }
            }
        }

        validEntries.sort(Comparator
                .comparing((DatedEntry item) -> item.date)
                .thenComparingLong(item -> item.entry.getId()));

        List<TrendPoint> points = new ArrayList<>(validEntries.size());
        Deque<Double> window = new ArrayDeque<>();
        double runningSum = 0;
        for (DatedEntry item : validEntries) {
            double weight = item.entry.getWeight();
            window.addLast(weight);
            runningSum += weight;
            if (window.size() > MOVING_AVERAGE_WINDOW) {
                runningSum -= window.removeFirst();
            }
            points.add(new TrendPoint(item.entry.getDate(), weight, runningSum / window.size()));
        }

        boolean hasGoal = goalWeight != null && Double.isFinite(goalWeight) && goalWeight > 0;
        int percentTowardGoal = hasGoal && !points.isEmpty()
                ? calculateGoalPercent(points.get(0).weight, points.get(points.size() - 1).weight, goalWeight)
                : 0;
        int improvementStreak = hasGoal ? countImprovementStreak(points, goalWeight) : 0;

        return new Analysis(points, ignoredEntries, hasGoal, percentTowardGoal, improvementStreak);
    }

    private static int calculateGoalPercent(double startingWeight, double currentWeight, double goalWeight) {
        double plannedChange = goalWeight - startingWeight;
        if (Math.abs(plannedChange) < EPSILON) {
            return 100;
        }
        double completedChange = currentWeight - startingWeight;
        int percent = (int) Math.round((completedChange / plannedChange) * 100.0);
        return Math.max(0, Math.min(100, percent));
    }

    private static int countImprovementStreak(List<TrendPoint> points, double goalWeight) {
        int streak = 0;
        for (int i = points.size() - 1; i > 0; i--) {
            double previousDistance = Math.abs(points.get(i - 1).weight - goalWeight);
            double currentDistance = Math.abs(points.get(i).weight - goalWeight);
            if (currentDistance + EPSILON < previousDistance) {
                streak++;
            } else {
                break;
            }
        }
        return streak;
    }

    private static final class DatedEntry {
        private final WeightEntry entry;
        private final LocalDate date;

        private DatedEntry(WeightEntry entry, LocalDate date) {
            this.entry = entry;
            this.date = date;
        }
    }

    public static final class TrendPoint {
        private final String date;
        private final double weight;
        private final double movingAverage;

        private TrendPoint(String date, double weight, double movingAverage) {
            this.date = date;
            this.weight = weight;
            this.movingAverage = movingAverage;
        }

        public String getDate() {
            return date;
        }

        public double getWeight() {
            return weight;
        }

        public double getMovingAverage() {
            return movingAverage;
        }
    }

    public static final class Analysis {
        private final List<TrendPoint> points;
        private final int ignoredEntries;
        private final boolean hasGoal;
        private final int percentTowardGoal;
        private final int improvementStreak;

        private Analysis(List<TrendPoint> points, int ignoredEntries, boolean hasGoal,
                         int percentTowardGoal, int improvementStreak) {
            this.points = Collections.unmodifiableList(new ArrayList<>(points));
            this.ignoredEntries = ignoredEntries;
            this.hasGoal = hasGoal;
            this.percentTowardGoal = percentTowardGoal;
            this.improvementStreak = improvementStreak;
        }

        public List<TrendPoint> getPoints() {
            return points;
        }

        public int getIgnoredEntries() {
            return ignoredEntries;
        }

        public boolean hasEntries() {
            return !points.isEmpty();
        }

        public boolean hasGoal() {
            return hasGoal;
        }

        public int getPercentTowardGoal() {
            return percentTowardGoal;
        }

        public int getImprovementStreak() {
            return improvementStreak;
        }

        public TrendPoint getStartingPoint() {
            return points.isEmpty() ? null : points.get(0);
        }

        public TrendPoint getCurrentPoint() {
            return points.isEmpty() ? null : points.get(points.size() - 1);
        }

        public double getTotalChange() {
            return points.size() < 2 ? 0 : getCurrentPoint().weight - getStartingPoint().weight;
        }

        public double getCurrentMovingAverage() {
            return points.isEmpty() ? 0 : getCurrentPoint().movingAverage;
        }
    }
}
