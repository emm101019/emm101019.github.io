package com.example.m3app_evamacaluso.util;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/** Shared validation rules keep every screen consistent and easier to test. */
public final class InputValidator {
    private InputValidator() {
    }

    public static String usernameError(String username) {
        String value = username == null ? "" : username.trim();
        if (value.isEmpty()) {
            return "Username is required";
        }
        if (value.length() < 3) {
            return "Username must have at least 3 characters";
        }
        if (value.length() > 30) {
            return "Username must have 30 characters or fewer";
        }
        return null;
    }

    public static String passwordError(String password) {
        String value = password == null ? "" : password;
        if (value.isEmpty()) {
            return "Password is required";
        }
        if (value.length() < 6) {
            return "Password must have at least 6 characters";
        }
        return null;
    }

    public static boolean isValidDate(String date) {
        try {
            LocalDate.parse(date == null ? "" : date.trim());
            return true;
        } catch (DateTimeParseException exception) {
            return false;
        }
    }

    public static Double parsePositiveWeight(String weightText) {
        try {
            double value = Double.parseDouble(weightText == null ? "" : weightText.trim());
            return value > 0 && value <= 1500 ? value : null;
        } catch (NumberFormatException exception) {
            return null;
        }
    }
}
