package com.example.m3app_evamacaluso;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.m3app_evamacaluso.data.WeightRepository;
import com.example.m3app_evamacaluso.model.WeightEntry;
import com.example.m3app_evamacaluso.util.InputValidator;
import com.example.m3app_evamacaluso.util.WeightProgressAnalyzer;

import java.util.List;

public class HomeActivity extends AppCompatActivity {
    public static final String EXTRA_USERNAME = "username";
    private static final String PREFERENCES = "weight_tracker_preferences";
    private static final String KEY_GOAL_WEIGHT = "goal_weight";

    private WeightRepository weights;
    private SharedPreferences preferences;
    private TextView currentWeightText;
    private TextView goalWeightText;
    private TextView progressPercentText;
    private TextView welcomeText;
    private TextView totalChangeText;
    private TextView movingAverageText;
    private TextView improvementStreakText;
    private TextView analysisMessageText;
    private ProgressBar progressBar;
    private WeightTrendView trendView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        weights = new WeightRepository(new DatabaseHelper(this));
        preferences = getSharedPreferences(PREFERENCES, MODE_PRIVATE);

        currentWeightText = findViewById(R.id.tvCurrentWeight);
        goalWeightText = findViewById(R.id.tvGoalWeight);
        progressPercentText = findViewById(R.id.tvProgressPercent);
        welcomeText = findViewById(R.id.tvWelcome);
        totalChangeText = findViewById(R.id.tvTotalChange);
        movingAverageText = findViewById(R.id.tvMovingAverage);
        improvementStreakText = findViewById(R.id.tvImprovementStreak);
        analysisMessageText = findViewById(R.id.tvAnalysisMessage);
        progressBar = findViewById(R.id.progressBar);
        trendView = findViewById(R.id.weightTrendView);
        Button addButton = findViewById(R.id.btnLogWorkout);
        Button historyButton = findViewById(R.id.btnStartActivity);
        Button goalButton = findViewById(R.id.btnSetGoal);

        String username = getIntent().getStringExtra(EXTRA_USERNAME);
        welcomeText.setText(username == null ? "Welcome" : "Welcome, " + username);

        addButton.setOnClickListener(v -> startActivity(new Intent(this, WeightEntryActivity.class)));
        historyButton.setOnClickListener(v -> startActivity(new Intent(this, WeightHistoryActivity.class)));
        goalButton.setOnClickListener(v -> showGoalDialog());
        findViewById(R.id.navAdd).setOnClickListener(v -> addButton.performClick());
        findViewById(R.id.navList).setOnClickListener(v -> historyButton.performClick());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshDashboard();
    }

    private void refreshDashboard() {
        List<WeightEntry> entries = weights.getAll();
        float storedGoal = preferences.getFloat(KEY_GOAL_WEIGHT, -1f);
        goalWeightText.setText(storedGoal > 0 ? String.format("Goal: %.1f lb", storedGoal) : "Goal: not set");

        Double goal = storedGoal > 0 ? (double) storedGoal : null;
        WeightProgressAnalyzer.Analysis analysis = WeightProgressAnalyzer.analyze(entries, goal);
        trendView.setTrendPoints(analysis.getPoints());
        analysisMessageText.setVisibility(analysis.getIgnoredEntries() > 0 ? TextView.VISIBLE : TextView.GONE);
        if (analysis.getIgnoredEntries() > 0) {
            analysisMessageText.setText("Some saved entries were skipped because their date or weight is invalid.");
        }

        if (!analysis.hasEntries()) {
            currentWeightText.setText("Current: no entries yet");
            totalChangeText.setText("Total change: --");
            movingAverageText.setText("7-entry average: --");
            improvementStreakText.setText("Improvement streak: --");
            progressPercentText.setText(storedGoal > 0 ? "0%" : "--");
            progressBar.setProgress(0);
            return;
        }

        WeightProgressAnalyzer.TrendPoint current = analysis.getCurrentPoint();
        currentWeightText.setText(String.format("Current: %.1f lb", current.getWeight()));
        totalChangeText.setText(String.format("Total change: %+.1f lb", analysis.getTotalChange()));
        movingAverageText.setText(String.format("7-entry average: %.1f lb", analysis.getCurrentMovingAverage()));
        improvementStreakText.setText("Improvement streak: " + analysis.getImprovementStreak()
                + " consecutive record(s)");
        if (storedGoal > 0) {
            progressBar.setProgress(analysis.getPercentTowardGoal());
            progressPercentText.setText(analysis.getPercentTowardGoal() + "%");
        } else {
            progressBar.setProgress(0);
            progressPercentText.setText("--");
        }
    }

    private void showGoalDialog() {
        EditText input = new EditText(this);
        input.setHint("Goal weight in pounds");
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        float currentGoal = preferences.getFloat(KEY_GOAL_WEIGHT, -1f);
        if (currentGoal > 0) {
            input.setText(String.valueOf(currentGoal));
        }

        AlertDialog alert = new AlertDialog.Builder(this)
                .setTitle("Set goal weight")
                .setView(input)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();
        alert.setOnShowListener(dialog ->
                alert.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                    Double goal = InputValidator.parsePositiveWeight(input.getText().toString());
                    if (goal == null) {
                        input.setError("Enter a valid weight");
                        return;
                    }
                    preferences.edit().putFloat(KEY_GOAL_WEIGHT, goal.floatValue()).apply();
                    Toast.makeText(this, "Goal saved", Toast.LENGTH_SHORT).show();
                    alert.dismiss();
                    refreshDashboard();
                })
        );
        alert.show();
    }
}
