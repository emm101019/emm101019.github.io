package com.example.m3app_evamacaluso.util;

/** Pure calculation class so progress behavior can be unit tested without Android. */
public final class ProgressCalculator {
    private ProgressCalculator() {
    }

    public static int percentTowardGoal(double startingWeight, double currentWeight, double goalWeight) {
        double totalChange = startingWeight - goalWeight;
        if (Math.abs(totalChange) < 0.0001) {
            return 100;
        }

        double completedChange = startingWeight - currentWeight;
        int percent = (int) Math.round((completedChange / totalChange) * 100.0);
        return Math.max(0, Math.min(100, percent));
    }
}
