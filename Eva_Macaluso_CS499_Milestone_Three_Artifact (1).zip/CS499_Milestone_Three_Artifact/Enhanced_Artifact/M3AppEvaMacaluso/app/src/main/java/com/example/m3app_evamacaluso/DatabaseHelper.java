package com.example.m3app_evamacaluso;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.m3app_evamacaluso.util.PasswordHasher;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database info
    private static final String DATABASE_NAME = "M3App.db";
    private static final int DATABASE_VERSION = 1;

    // Users table (login)
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // Weight tracker table (generic records table for now)
    public static final String TABLE_RECORDS = "records";
    public static final String COL_RECORD_ID = "record_id";
    public static final String COL_RECORD_NAME = "record_name";   // use for date
    public static final String COL_RECORD_VALUE = "record_value"; // use for weight

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT UNIQUE, "
                + COL_PASSWORD + " TEXT)";

        // Create weight records table
        String createRecordsTable = "CREATE TABLE " + TABLE_RECORDS + " ("
                + COL_RECORD_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_RECORD_NAME + " TEXT, "
                + COL_RECORD_VALUE + " TEXT)";

        db.execSQL(createUsersTable);
        db.execSQL(createRecordsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RECORDS);
        onCreate(db);
    }

    // =========================
    // USER LOGIN / REGISTER
    // =========================

    // Check if username already exists
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + COL_USERNAME + "=?",
                new String[]{username}
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Insert new user account
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, PasswordHasher.hash(password));

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // Check login credentials
    public boolean checkLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        try (Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_USER_ID, COL_PASSWORD},
                COL_USERNAME + "=?",
                new String[]{username},
                null,
                null,
                null,
                "1"
        )) {
            if (!cursor.moveToFirst()) {
                return false;
            }
            long userId = cursor.getLong(cursor.getColumnIndexOrThrow(COL_USER_ID));
            String storedPassword = cursor.getString(cursor.getColumnIndexOrThrow(COL_PASSWORD));
            if (PasswordHasher.isHashed(storedPassword)) {
                return PasswordHasher.verify(password, storedPassword);
            }

            // Upgrade an account created by the original app after one successful login.
            if (password.equals(storedPassword)) {
                ContentValues values = new ContentValues();
                values.put(COL_PASSWORD, PasswordHasher.hash(password));
                db.update(TABLE_USERS, values, COL_USER_ID + "=?", new String[]{String.valueOf(userId)});
                return true;
            }
            return false;
        }
    }

    // =========================
    // WEIGHT TRACKER CRUD
    // =========================

    // CREATE - add weight entry
    public boolean insertWeightEntry(String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_RECORD_NAME, date);
        values.put(COL_RECORD_VALUE, weight);

        long result = db.insert(TABLE_RECORDS, null, values);
        return result != -1;
    }

    // READ - get all entries
    public Cursor getAllWeightEntries() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(
                TABLE_RECORDS,
                null,
                null,
                null,
                null,
                null,
                COL_RECORD_NAME + " DESC, " + COL_RECORD_ID + " DESC"
        );
    }

    // READ - get one entry for the edit screen
    public Cursor getWeightEntryById(String id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(
                TABLE_RECORDS,
                null,
                COL_RECORD_ID + "=?",
                new String[]{id},
                null,
                null,
                null,
                "1"
        );
    }

    // UPDATE - update entry by id
    public boolean updateWeightEntry(String id, String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_RECORD_NAME, date);
        values.put(COL_RECORD_VALUE, weight);

        int rows = db.update(TABLE_RECORDS, values, COL_RECORD_ID + "=?", new String[]{id});
        return rows > 0;
    }

    // DELETE - delete entry by id
    public boolean deleteWeightEntry(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_RECORDS, COL_RECORD_ID + "=?", new String[]{id});
        return rows > 0;
    }
}
