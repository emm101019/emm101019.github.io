package com.example.m3app_evamacaluso;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import com.example.m3app_evamacaluso.util.WeightProgressAnalyzer;

import java.util.ArrayList;
import java.util.List;

/** Draws weight entries and their seven-entry moving average in date order. */
public final class WeightTrendView extends View {
    private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint weightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint averagePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pointPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint messagePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint axisPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<WeightProgressAnalyzer.TrendPoint> points = new ArrayList<>();

    public WeightTrendView(Context context) {
        super(context);
        initialize();
    }

    public WeightTrendView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize();
    }

    public WeightTrendView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initialize();
    }

    private void initialize() {
        gridPaint.setColor(Color.LTGRAY);
        gridPaint.setStrokeWidth(dp(1));
        weightPaint.setColor(Color.rgb(39, 100, 85));
        weightPaint.setStrokeWidth(dp(2.5f));
        weightPaint.setStyle(Paint.Style.STROKE);
        weightPaint.setStrokeCap(Paint.Cap.ROUND);
        weightPaint.setStrokeJoin(Paint.Join.ROUND);
        averagePaint.setColor(Color.rgb(193, 99, 64));
        averagePaint.setStrokeWidth(dp(2.5f));
        averagePaint.setStyle(Paint.Style.STROKE);
        averagePaint.setStrokeCap(Paint.Cap.ROUND);
        averagePaint.setStrokeJoin(Paint.Join.ROUND);
        pointPaint.setColor(weightPaint.getColor());
        messagePaint.setColor(Color.DKGRAY);
        messagePaint.setTextSize(dp(14));
        axisPaint.setColor(Color.DKGRAY);
        axisPaint.setTextSize(dp(10));
        setContentDescription("Weight trend chart. Add weight entries to see progress.");
    }

    public void setTrendPoints(List<WeightProgressAnalyzer.TrendPoint> trendPoints) {
        points = trendPoints == null ? new ArrayList<>() : new ArrayList<>(trendPoints);
        if (points.isEmpty()) {
            setContentDescription("Weight trend chart. No valid weight entries are available.");
        } else {
            WeightProgressAnalyzer.TrendPoint first = points.get(0);
            WeightProgressAnalyzer.TrendPoint last = points.get(points.size() - 1);
            setContentDescription("Weight trend chart with " + points.size() + " dated entries, from "
                    + first.getDate() + " at " + first.getWeight() + " pounds to "
                    + last.getDate() + " at " + last.getWeight() + " pounds. The second line shows "
                    + "the seven-entry moving average.");
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float left = dp(42);
        float right = getWidth() - dp(10);
        float top = dp(12);
        float bottom = getHeight() - dp(28);
        if (right <= left || bottom <= top) {
            return;
        }
        if (points.isEmpty()) {
            canvas.drawText("Add weight entries to see your trend.", left, top + dp(20), messagePaint);
            return;
        }

        float[] bounds = getWeightBounds();
        float min = bounds[0];
        float max = bounds[1];
        float range = Math.max(max - min, 1.0f);
        min -= range * 0.08f;
        max += range * 0.08f;
        float adjustedRange = max - min;

        for (int line = 0; line <= 2; line++) {
            float y = top + (bottom - top) * line / 2f;
            canvas.drawLine(left, y, right, y, gridPaint);
        }

        drawSeries(canvas, left, right, top, bottom, min, adjustedRange, false);
        drawSeries(canvas, left, right, top, bottom, min, adjustedRange, true);
        canvas.drawText(String.format("%.0f", max), dp(2), top + dp(4), axisPaint);
        canvas.drawText(String.format("%.0f", min), dp(2), bottom, axisPaint);
        canvas.drawText(points.get(0).getDate(), left, getHeight() - dp(5), axisPaint);
        String endDate = points.get(points.size() - 1).getDate();
        canvas.drawText(endDate, right - axisPaint.measureText(endDate), getHeight() - dp(5), axisPaint);
    }

    private float[] getWeightBounds() {
        double min = Double.MAX_VALUE;
        double max = -Double.MAX_VALUE;
        for (WeightProgressAnalyzer.TrendPoint point : points) {
            min = Math.min(min, Math.min(point.getWeight(), point.getMovingAverage()));
            max = Math.max(max, Math.max(point.getWeight(), point.getMovingAverage()));
        }
        return new float[]{(float) min, (float) max};
    }

    private void drawSeries(Canvas canvas, float left, float right, float top, float bottom,
                            float min, float range, boolean useAverage) {
        Paint linePaint = useAverage ? averagePaint : weightPaint;
        float previousX = 0;
        float previousY = 0;
        for (int i = 0; i < points.size(); i++) {
            WeightProgressAnalyzer.TrendPoint point = points.get(i);
            float value = (float) (useAverage ? point.getMovingAverage() : point.getWeight());
            float x = points.size() == 1
                    ? (left + right) / 2f
                    : left + (right - left) * i / (points.size() - 1f);
            float y = bottom - ((value - min) / range) * (bottom - top);
            if (i > 0) {
                canvas.drawLine(previousX, previousY, x, y, linePaint);
            } else if (!useAverage) {
                canvas.drawCircle(x, y, dp(3.5f), pointPaint);
            }
            previousX = x;
            previousY = y;
        }
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
