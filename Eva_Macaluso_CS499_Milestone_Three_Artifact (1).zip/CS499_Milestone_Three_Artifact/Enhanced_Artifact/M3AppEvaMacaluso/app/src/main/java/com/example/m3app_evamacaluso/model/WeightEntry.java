package com.example.m3app_evamacaluso.model;

/** Immutable value object used by the UI instead of passing database cursors around. */
public final class WeightEntry {
    private final long id;
    private final String date;
    private final double weight;

    public WeightEntry(long id, String date, double weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    public long getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public double getWeight() {
        return weight;
    }
}
