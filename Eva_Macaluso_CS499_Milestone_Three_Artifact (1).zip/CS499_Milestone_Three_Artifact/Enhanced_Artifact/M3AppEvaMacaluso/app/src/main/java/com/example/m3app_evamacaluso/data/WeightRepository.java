package com.example.m3app_evamacaluso.data;

import android.database.Cursor;

import com.example.m3app_evamacaluso.DatabaseHelper;
import com.example.m3app_evamacaluso.model.WeightEntry;

import java.util.ArrayList;
import java.util.List;

/** Converts database rows into model objects and gives the UI a small CRUD interface. */
public final class WeightRepository {
    private final DatabaseHelper database;

    public WeightRepository(DatabaseHelper database) {
        this.database = database;
    }

    public boolean add(String date, double weight) {
        return database.insertWeightEntry(date, String.valueOf(weight));
    }

    public boolean update(long id, String date, double weight) {
        return database.updateWeightEntry(String.valueOf(id), date, String.valueOf(weight));
    }

    public boolean delete(long id) {
        return database.deleteWeightEntry(String.valueOf(id));
    }

    public WeightEntry get(long id) {
        try (Cursor cursor = database.getWeightEntryById(String.valueOf(id))) {
            if (cursor.moveToFirst()) {
                return fromCursor(cursor);
            }
        }
        return null;
    }

    public List<WeightEntry> getAll() {
        List<WeightEntry> entries = new ArrayList<>();
        try (Cursor cursor = database.getAllWeightEntries()) {
            while (cursor.moveToNext()) {
                entries.add(fromCursor(cursor));
            }
        }
        return entries;
    }

    private WeightEntry fromCursor(Cursor cursor) {
        long id = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_RECORD_ID));
        String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_RECORD_NAME));
        String storedWeight = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_RECORD_VALUE));
        double weight;
        try {
            weight = Double.parseDouble(storedWeight);
        } catch (NumberFormatException exception) {
            weight = 0;
        }
        return new WeightEntry(id, date, weight);
    }
}
