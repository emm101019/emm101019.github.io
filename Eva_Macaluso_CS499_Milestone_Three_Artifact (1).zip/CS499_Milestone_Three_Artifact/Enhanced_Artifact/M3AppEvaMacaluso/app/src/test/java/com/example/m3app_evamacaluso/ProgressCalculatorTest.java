package com.example.m3app_evamacaluso;

import static org.junit.Assert.assertEquals;

import com.example.m3app_evamacaluso.util.ProgressCalculator;

import org.junit.Test;

public class ProgressCalculatorTest {
    @Test
    public void calculatesProgressTowardLowerGoal() {
        assertEquals(50, ProgressCalculator.percentTowardGoal(200, 175, 150));
    }

    @Test
    public void clampsProgressToValidRange() {
        assertEquals(0, ProgressCalculator.percentTowardGoal(200, 210, 150));
        assertEquals(100, ProgressCalculator.percentTowardGoal(200, 140, 150));
    }
}
