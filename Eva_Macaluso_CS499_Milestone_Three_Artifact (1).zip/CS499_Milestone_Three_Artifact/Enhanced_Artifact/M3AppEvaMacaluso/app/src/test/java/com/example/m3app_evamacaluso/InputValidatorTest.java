package com.example.m3app_evamacaluso;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import com.example.m3app_evamacaluso.util.InputValidator;

import org.junit.Test;

public class InputValidatorTest {
    @Test
    public void validCredentialsReturnNoError() {
        assertNull(InputValidator.usernameError("eva123"));
        assertNull(InputValidator.passwordError("secret1"));
    }

    @Test
    public void shortCredentialsReturnUsefulErrors() {
        assertEquals("Username must have at least 3 characters", InputValidator.usernameError("ev"));
        assertEquals("Password must have at least 6 characters", InputValidator.passwordError("123"));
    }

    @Test
    public void dateAndWeightValidationRejectsBadInput() {
        assertTrue(InputValidator.isValidDate("2026-09-27"));
        assertFalse(InputValidator.isValidDate("09/27/26"));
        assertNull(InputValidator.parsePositiveWeight("-5"));
        assertEquals(165.5, InputValidator.parsePositiveWeight("165.5"), 0.001);
    }
}
