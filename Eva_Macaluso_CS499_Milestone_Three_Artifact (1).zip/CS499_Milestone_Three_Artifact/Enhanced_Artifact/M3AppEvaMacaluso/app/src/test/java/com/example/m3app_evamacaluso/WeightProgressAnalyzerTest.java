package com.example.m3app_evamacaluso;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.example.m3app_evamacaluso.model.WeightEntry;
import com.example.m3app_evamacaluso.util.WeightProgressAnalyzer;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class WeightProgressAnalyzerTest {
    @Test
    public void emptyHistoryReturnsNoPoints() {
        WeightProgressAnalyzer.Analysis result = WeightProgressAnalyzer.analyze(new ArrayList<>(), 150.0);

        assertFalse(result.hasEntries());
        assertEquals(0, result.getPercentTowardGoal());
        assertEquals(0, result.getImprovementStreak());
    }

    @Test
    public void sortsDatesAndDoesNotChangeInputList() {
        List<WeightEntry> entries = new ArrayList<>(Arrays.asList(
                new WeightEntry(3, "2026-03-03", 180),
                new WeightEntry(1, "2026-03-01", 200),
                new WeightEntry(2, "2026-03-02", 190)
        ));

        WeightProgressAnalyzer.Analysis result = WeightProgressAnalyzer.analyze(entries, 160.0);

        assertEquals("2026-03-01", result.getStartingPoint().getDate());
        assertEquals("2026-03-03", result.getCurrentPoint().getDate());
        assertEquals(180.0, result.getCurrentPoint().getWeight(), 0.001);
        assertEquals(50, result.getPercentTowardGoal());
        assertEquals(3, entries.get(0).getId());
    }

    @Test
    public void duplicateDatesUseRecordIdForStableOrdering() {
        List<WeightEntry> entries = Arrays.asList(
                new WeightEntry(7, "2026-03-01", 170),
                new WeightEntry(3, "2026-03-01", 180)
        );

        WeightProgressAnalyzer.Analysis result = WeightProgressAnalyzer.analyze(entries, 150.0);

        assertEquals(180.0, result.getStartingPoint().getWeight(), 0.001);
        assertEquals(170.0, result.getCurrentPoint().getWeight(), 0.001);
    }

    @Test
    public void movingAverageUsesRollingSevenEntryWindow() {
        List<WeightEntry> entries = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            entries.add(new WeightEntry(i + 1, String.format("2026-03-%02d", i + 1), 100 + i));
        }

        WeightProgressAnalyzer.Analysis result = WeightProgressAnalyzer.analyze(entries, null);

        assertEquals(103.0, result.getPoints().get(6).getMovingAverage(), 0.001);
        assertEquals(104.0, result.getCurrentMovingAverage(), 0.001);
        assertFalse(result.hasGoal());
    }

    @Test
    public void handlesWeightGainGoalAndClampsProgress() {
        List<WeightEntry> entries = Arrays.asList(
                new WeightEntry(1, "2026-03-01", 150),
                new WeightEntry(2, "2026-03-02", 175)
        );

        WeightProgressAnalyzer.Analysis result = WeightProgressAnalyzer.analyze(entries, 200.0);
        WeightProgressAnalyzer.Analysis overGoal = WeightProgressAnalyzer.analyze(
                Arrays.asList(new WeightEntry(1, "2026-03-01", 150),
                        new WeightEntry(2, "2026-03-02", 205)), 200.0);

        assertEquals(50, result.getPercentTowardGoal());
        assertEquals(100, overGoal.getPercentTowardGoal());
        assertEquals(1, result.getImprovementStreak());
    }

    @Test
    public void countsOnlyCurrentConsecutiveImprovements() {
        List<WeightEntry> entries = Arrays.asList(
                new WeightEntry(1, "2026-03-01", 200),
                new WeightEntry(2, "2026-03-02", 190),
                new WeightEntry(3, "2026-03-03", 195),
                new WeightEntry(4, "2026-03-04", 175)
        );

        WeightProgressAnalyzer.Analysis result = WeightProgressAnalyzer.analyze(entries, 150.0);

        assertEquals(1, result.getImprovementStreak());
    }

    @Test
    public void ignoresInvalidDatesAndWeights() {
        List<WeightEntry> entries = Arrays.asList(
                new WeightEntry(1, "not-a-date", 180),
                new WeightEntry(2, "2026-03-01", Double.NaN),
                new WeightEntry(3, "2026-03-02", 180)
        );

        WeightProgressAnalyzer.Analysis result = WeightProgressAnalyzer.analyze(entries, 150.0);

        assertEquals(2, result.getIgnoredEntries());
        assertEquals(1, result.getPoints().size());
        assertEquals("2026-03-02", result.getCurrentPoint().getDate());
    }

    @Test
    public void oneEntryProvidesInitialMovingAverageAndGoalState() {
        WeightProgressAnalyzer.Analysis result = WeightProgressAnalyzer.analyze(
                Arrays.asList(new WeightEntry(1, "2026-03-01", 170)), 160.0);

        assertEquals(170.0, result.getCurrentMovingAverage(), 0.001);
        assertEquals(0, result.getTotalChange(), 0.001);
        assertEquals(0, result.getImprovementStreak());
    }

    @Test
    public void analyzesLargerHistory() {
        List<WeightEntry> entries = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            entries.add(new WeightEntry(i + 1, "2026-01-01", 200 - (i * 0.01)));
        }

        WeightProgressAnalyzer.Analysis result = WeightProgressAnalyzer.analyze(entries, 190.0);

        assertEquals(1000, result.getPoints().size());
        assertEquals(100, result.getPercentTowardGoal());
        assertTrue(result.getCurrentMovingAverage() > 190.0);
    }
}
