package com.example.m3app_evamacaluso;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.m3app_evamacaluso.data.WeightRepository;
import com.example.m3app_evamacaluso.model.WeightEntry;
import com.example.m3app_evamacaluso.util.InputValidator;
import com.example.m3app_evamacaluso.util.ProgressCalculator;

import java.util.List;

public class HomeActivity extends AppCompatActivity {
    public static final String EXTRA_USERNAME = "username";
    private static final String PREFERENCES = "weight_tracker_preferences";
    private static final String KEY_GOAL_WEIGHT = "goal_weight";

    private WeightRepository weights;
    private SharedPreferences preferences;
    private TextView currentWeightText;
    private TextView goalWeightText;
    private TextView progressPercentText;
    private TextView welcomeText;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        weights = new WeightRepository(new DatabaseHelper(this));
        preferences = getSharedPreferences(PREFERENCES, MODE_PRIVATE);

        currentWeightText = findViewById(R.id.tvCurrentWeight);
        goalWeightText = findViewById(R.id.tvGoalWeight);
        progressPercentText = findViewById(R.id.tvProgressPercent);
        welcomeText = findViewById(R.id.tvWelcome);
        progressBar = findViewById(R.id.progressBar);
        Button addButton = findViewById(R.id.btnLogWorkout);
        Button historyButton = findViewById(R.id.btnStartActivity);
        Button goalButton = findViewById(R.id.btnSetGoal);

        String username = getIntent().getStringExtra(EXTRA_USERNAME);
        welcomeText.setText(username == null ? "Welcome" : "Welcome, " + username);

        addButton.setOnClickListener(v -> startActivity(new Intent(this, WeightEntryActivity.class)));
        historyButton.setOnClickListener(v -> startActivity(new Intent(this, WeightHistoryActivity.class)));
        goalButton.setOnClickListener(v -> showGoalDialog());
        findViewById(R.id.navAdd).setOnClickListener(v -> addButton.performClick());
        findViewById(R.id.navList).setOnClickListener(v -> historyButton.performClick());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshDashboard();
    }

    private void refreshDashboard() {
        List<WeightEntry> entries = weights.getAll();
        float storedGoal = preferences.getFloat(KEY_GOAL_WEIGHT, -1f);
        goalWeightText.setText(storedGoal > 0 ? String.format("Goal: %.1f lb", storedGoal) : "Goal: not set");

        if (entries.isEmpty()) {
            currentWeightText.setText("Current: no entries yet");
            progressPercentText.setText("0%");
            progressBar.setProgress(0);
            return;
        }

        WeightEntry current = entries.get(0);
        WeightEntry starting = entries.get(entries.size() - 1);
        currentWeightText.setText(String.format("Current: %.1f lb", current.getWeight()));
        int percent = storedGoal > 0
                ? ProgressCalculator.percentTowardGoal(starting.getWeight(), current.getWeight(), storedGoal)
                : 0;
        progressBar.setProgress(percent);
        progressPercentText.setText(percent + "%");
    }

    private void showGoalDialog() {
        EditText input = new EditText(this);
        input.setHint("Goal weight in pounds");
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        float currentGoal = preferences.getFloat(KEY_GOAL_WEIGHT, -1f);
        if (currentGoal > 0) {
            input.setText(String.valueOf(currentGoal));
        }

        AlertDialog alert = new AlertDialog.Builder(this)
                .setTitle("Set goal weight")
                .setView(input)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();
        alert.setOnShowListener(dialog ->
                alert.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                    Double goal = InputValidator.parsePositiveWeight(input.getText().toString());
                    if (goal == null) {
                        input.setError("Enter a valid weight");
                        return;
                    }
                    preferences.edit().putFloat(KEY_GOAL_WEIGHT, goal.floatValue()).apply();
                    Toast.makeText(this, "Goal saved", Toast.LENGTH_SHORT).show();
                    alert.dismiss();
                    refreshDashboard();
                })
        );
        alert.show();
    }
}
