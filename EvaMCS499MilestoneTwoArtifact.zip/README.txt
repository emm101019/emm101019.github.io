CS 499 Milestone Two Technical Artifact
Eva Macaluso

Original_Artifact contains the complete original CS 360 Weight Tracker project.
Enhanced_Artifact contains the complete project after the software design and engineering enhancement.

Open the M3AppEvaMacaluso folder in Android Studio. The enhanced project includes its own ENHANCEMENT_ONE_README.md with a summary of the changes.
