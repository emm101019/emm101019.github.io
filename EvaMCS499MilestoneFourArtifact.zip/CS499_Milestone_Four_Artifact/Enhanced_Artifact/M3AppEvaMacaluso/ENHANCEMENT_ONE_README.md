# CS 499 Enhancement One

This folder contains the enhanced CS 360 Weight Tracker Android application for the software design and engineering category.

## Main improvements

- Added model, repository, validation, and calculation classes to separate responsibilities.
- Refactored login and account creation into smaller methods with field-level validation.
- Added working screens to create, view, edit, and delete weight entries.
- Connected the home screen to saved weight data and added a goal-progress display.
- Added clearer success and error feedback, confirmation before deletion, and content descriptions.
- Added unit tests for shared validation and progress calculation logic.
- Replaced plain-text password storage with salted PBKDF2 hashes and automatic legacy-account upgrades.
- Removed the unused SMS permission, disabled app-data backup, and blocked cleartext network traffic.
- Removed unused prototype database and SMS layouts that were no longer part of the working navigation.
- Declared the missing CardView dependency and lowered the minimum Android version from 34 to 26.

At this stage, SQLite remained in place. The later database enhancement replaces it with Room and adds account relationships and a data migration.
