# CS 499 Enhancement Three

This enhancement updates the Weight Tracker database. The enhanced project now uses Android Room instead of direct SQLite helper methods.

## What changed

- Added Room entities and DAOs for accounts and weight entries.
- Added a Room migration from the previous SQLite schema. It keeps account IDs and valid weight history instead of dropping the old tables. Existing history is assigned to the first account when possible. Unassigned legacy history is attached to the first account that logs in.
- Stored weights as numbers and linked each new entry to its account with a foreign key.
- Added an index for account and date lookups.
- Added account-scoped create, read, update, and delete operations in the repository.
- Kept password hashes in the account table. A legacy plain-text password is upgraded after a successful login.
- Added an Android database test for saving, reading, updating, deleting, and separating entries by account.

## Testing

The database test is in `app/src/androidTest/java/com/example/m3app_evamacaluso/RoomDatabaseTest.java`. Run it from Android Studio on an emulator or device. Existing unit tests cover validation, progress calculations, and weight-history analysis.
