package com.example.m3app_evamacaluso.database;

import android.content.Context;
import android.database.Cursor;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {UserEntity.class, WeightEntryEntity.class}, version = 2, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    private static volatile AppDatabase instance;

    public abstract UserDao userDao();
    public abstract WeightEntryDao weightEntryDao();

    public static AppDatabase getInstance(Context context) {
        if (instance == null) {
            synchronized (AppDatabase.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(context.getApplicationContext(), AppDatabase.class, "M3App.db")
                            .addMigrations(MIGRATION_1_2)
                            .allowMainThreadQueries()
                            .build();
                }
            }
        }
        return instance;
    }

    static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase db) {
            // Room requires non-null user fields and a named unique index.
            db.execSQL("CREATE TABLE users_new (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "
                    + "username TEXT NOT NULL, password TEXT NOT NULL)");
            db.execSQL("INSERT INTO users_new(id, username, password) "
                    + "SELECT id, COALESCE(username, 'legacy_' || id), COALESCE(password, '') FROM users");
            db.execSQL("DROP TABLE users");
            db.execSQL("ALTER TABLE users_new RENAME TO users");
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_users_username ON users(username)");
            db.execSQL("CREATE TABLE IF NOT EXISTS weight_entries ("
                    + "entryId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "
                    + "userId INTEGER, date TEXT NOT NULL, weight REAL NOT NULL CHECK(weight > 0), "
                    + "FOREIGN KEY(userId) REFERENCES users(id) ON UPDATE NO ACTION ON DELETE SET NULL)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_weight_entries_userId_date "
                    + "ON weight_entries(userId, date)");
            if (tableExists(db, "records")) {
                String owner = tableExists(db, "users")
                        ? "(SELECT id FROM users ORDER BY id LIMIT 1)" : "NULL";
                db.execSQL("INSERT INTO weight_entries(entryId, userId, date, weight) "
                        + "SELECT record_id, " + owner + ", record_name, CAST(record_value AS REAL) "
                        + "FROM records WHERE record_name IS NOT NULL AND length(record_name) = 10 "
                        + "AND CAST(record_value AS REAL) > 0");
                db.execSQL("DROP TABLE records");
            }
        }
    };

    private static boolean tableExists(SupportSQLiteDatabase db, String tableName) {
        try (Cursor cursor = db.query("SELECT name FROM sqlite_master WHERE type='table' AND name=?", new Object[]{tableName})) {
            return cursor.moveToFirst();
        }
    }
}
