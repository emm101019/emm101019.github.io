package com.example.m3app_evamacaluso.data;

import com.example.m3app_evamacaluso.DatabaseHelper;
import com.example.m3app_evamacaluso.database.AppDatabase;
import com.example.m3app_evamacaluso.database.UserEntity;
import com.example.m3app_evamacaluso.util.PasswordHasher;

/** Account operations separated from Android activities. */
public final class UserRepository {
    private final AppDatabase database;

    public UserRepository(DatabaseHelper helper) {
        database = helper.database();
    }

    public boolean exists(String username) {
        return database.userDao().findByUsername(username) != null;
    }

    public boolean create(String username, String password) {
        try {
            database.userDao().insert(new UserEntity(username, PasswordHasher.hash(password)));
            return true;
        } catch (android.database.sqlite.SQLiteConstraintException exception) {
            return false;
        }
    }

    /** Returns the account ID after login, or -1 when the credentials are invalid. */
    public long authenticate(String username, String password) {
        UserEntity user = database.userDao().findByUsername(username);
        if (user == null) return -1;
        boolean valid;
        if (PasswordHasher.isHashed(user.password)) {
            valid = PasswordHasher.verify(password, user.password);
        } else {
            valid = password.equals(user.password);
            if (valid) database.userDao().updatePassword(user.id, PasswordHasher.hash(password));
        }
        if (!valid) return -1;
        database.runInTransaction(() -> database.weightEntryDao().assignLegacyEntries(user.id));
        return user.id;
    }
}
