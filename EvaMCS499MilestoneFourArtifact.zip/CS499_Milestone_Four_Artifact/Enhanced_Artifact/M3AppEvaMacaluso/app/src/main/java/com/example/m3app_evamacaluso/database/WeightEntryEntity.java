package com.example.m3app_evamacaluso.database;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "weight_entries",
        foreignKeys = @ForeignKey(entity = UserEntity.class, parentColumns = "id",
                childColumns = "userId", onDelete = ForeignKey.SET_NULL),
        indices = {@Index(value = {"userId", "date"})})
public class WeightEntryEntity {
    @PrimaryKey(autoGenerate = true)
    public long entryId;
    public Long userId;
    public String date;
    public double weight;

    public WeightEntryEntity(Long userId, String date, double weight) {
        this.userId = userId;
        this.date = date;
        this.weight = weight;
    }
}
