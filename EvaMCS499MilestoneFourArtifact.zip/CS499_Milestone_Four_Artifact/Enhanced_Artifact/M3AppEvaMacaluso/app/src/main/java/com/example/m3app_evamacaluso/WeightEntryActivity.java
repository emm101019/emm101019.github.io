package com.example.m3app_evamacaluso;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.m3app_evamacaluso.data.WeightRepository;
import com.example.m3app_evamacaluso.model.WeightEntry;
import com.example.m3app_evamacaluso.util.InputValidator;

import java.time.LocalDate;

public class WeightEntryActivity extends AppCompatActivity {
    public static final String EXTRA_ENTRY_ID = "entry_id";

    private EditText dateField;
    private EditText weightField;
    private WeightRepository weights;
    private long entryId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_entry);

        long userId = getIntent().getLongExtra(HomeActivity.EXTRA_USER_ID, -1);
        weights = new WeightRepository(new DatabaseHelper(this), userId);
        dateField = findViewById(R.id.dateField);
        weightField = findViewById(R.id.weightField);
        Button saveButton = findViewById(R.id.saveWeightButton);
        Button cancelButton = findViewById(R.id.cancelWeightButton);

        entryId = getIntent().getLongExtra(EXTRA_ENTRY_ID, -1);
        if (entryId >= 0) {
            loadEntry(entryId);
            saveButton.setText("Update entry");
        } else {
            dateField.setText(LocalDate.now().toString());
        }

        saveButton.setOnClickListener(v -> saveEntry());
        cancelButton.setOnClickListener(v -> finish());
    }

    private void loadEntry(long id) {
        WeightEntry entry = weights.get(id);
        if (entry == null) {
            Toast.makeText(this, "Entry could not be loaded", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        dateField.setText(entry.getDate());
        weightField.setText(String.valueOf(entry.getWeight()));
    }

    private void saveEntry() {
        String date = dateField.getText().toString().trim();
        Double weight = InputValidator.parsePositiveWeight(weightField.getText().toString());
        dateField.setError(InputValidator.isValidDate(date) ? null : "Use the format YYYY-MM-DD");
        weightField.setError(weight == null ? "Enter a valid weight" : null);
        if (dateField.getError() != null || weightField.getError() != null) {
            return;
        }

        boolean saved = entryId >= 0
                ? weights.update(entryId, date, weight)
                : weights.add(date, weight);
        if (!saved) {
            Toast.makeText(this, "Entry could not be saved", Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, entryId >= 0 ? "Entry updated" : "Entry added", Toast.LENGTH_SHORT).show();
        finish();
    }
}
