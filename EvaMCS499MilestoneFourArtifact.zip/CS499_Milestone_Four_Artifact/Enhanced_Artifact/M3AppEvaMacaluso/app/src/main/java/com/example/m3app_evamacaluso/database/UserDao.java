package com.example.m3app_evamacaluso.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface UserDao {
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    UserEntity findByUsername(String username);

    @Insert
    long insert(UserEntity user);

    @Query("UPDATE users SET password = :password WHERE id = :userId")
    int updatePassword(long userId, String password);
}
