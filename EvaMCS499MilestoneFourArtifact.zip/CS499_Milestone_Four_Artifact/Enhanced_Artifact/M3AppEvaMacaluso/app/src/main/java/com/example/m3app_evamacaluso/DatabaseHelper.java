package com.example.m3app_evamacaluso;

import android.content.Context;

import com.example.m3app_evamacaluso.database.AppDatabase;

/** Keeps the existing activity construction simple while all persistence uses Room. */
@Deprecated
public class DatabaseHelper {
    private final AppDatabase database;

    public DatabaseHelper(Context context) {
        database = AppDatabase.getInstance(context);
    }

    public AppDatabase database() {
        return database;
    }
}
