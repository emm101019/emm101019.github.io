package com.example.m3app_evamacaluso;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.m3app_evamacaluso.data.WeightRepository;
import com.example.m3app_evamacaluso.model.WeightEntry;

import java.util.List;

public class WeightHistoryActivity extends AppCompatActivity {
    private WeightRepository weights;
    private LinearLayout entriesContainer;
    private TextView emptyMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_history);
        long userId = getIntent().getLongExtra(HomeActivity.EXTRA_USER_ID, -1);
        weights = new WeightRepository(new DatabaseHelper(this), userId);
        entriesContainer = findViewById(R.id.entriesContainer);
        emptyMessage = findViewById(R.id.emptyMessage);
        findViewById(R.id.addFromHistoryButton).setOnClickListener(
                v -> startActivity(new Intent(this, WeightEntryActivity.class)
                        .putExtra(HomeActivity.EXTRA_USER_ID,
                                getIntent().getLongExtra(HomeActivity.EXTRA_USER_ID, -1)))
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        showEntries();
    }

    private void showEntries() {
        entriesContainer.removeAllViews();
        List<WeightEntry> entries = weights.getAll();
        emptyMessage.setVisibility(entries.isEmpty() ? View.VISIBLE : View.GONE);
        for (WeightEntry entry : entries) {
            entriesContainer.addView(buildEntryRow(entry));
        }
    }

    private View buildEntryRow(WeightEntry entry) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(24, 18, 24, 18);

        TextView summary = new TextView(this);
        summary.setText(String.format("%s   %.1f lb", entry.getDate(), entry.getWeight()));
        summary.setTextSize(18);
        summary.setTypeface(null, Typeface.BOLD);
        row.addView(summary);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button edit = new Button(this);
        edit.setText("Edit");
        edit.setContentDescription("Edit weight entry from " + entry.getDate());
        edit.setOnClickListener(v -> {
            Intent intent = new Intent(this, WeightEntryActivity.class);
            intent.putExtra(WeightEntryActivity.EXTRA_ENTRY_ID, entry.getId());
            intent.putExtra(HomeActivity.EXTRA_USER_ID,
                    getIntent().getLongExtra(HomeActivity.EXTRA_USER_ID, -1));
            startActivity(intent);
        });
        actions.addView(edit);

        Button delete = new Button(this);
        delete.setText("Delete");
        delete.setContentDescription("Delete weight entry from " + entry.getDate());
        delete.setOnClickListener(v -> confirmDelete(entry));
        actions.addView(delete);
        row.addView(actions);
        return row;
    }

    private void confirmDelete(WeightEntry entry) {
        new AlertDialog.Builder(this)
                .setTitle("Delete entry?")
                .setMessage(entry.getDate() + " - " + String.format("%.1f lb", entry.getWeight()))
                .setPositiveButton("Delete", (dialog, which) -> {
                    if (weights.delete(entry.getId())) {
                        Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show();
                        showEntries();
                    } else {
                        Toast.makeText(this, "Entry could not be deleted", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
