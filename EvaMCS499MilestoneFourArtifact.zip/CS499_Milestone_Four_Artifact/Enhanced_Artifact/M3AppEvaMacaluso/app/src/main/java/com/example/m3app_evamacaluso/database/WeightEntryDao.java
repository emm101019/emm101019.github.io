package com.example.m3app_evamacaluso.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface WeightEntryDao {
    @Insert
    long insert(WeightEntryEntity entry);

    @Update
    int update(WeightEntryEntity entry);

    @Query("DELETE FROM weight_entries WHERE entryId = :entryId AND userId = :userId")
    int delete(long entryId, long userId);

    @Query("SELECT * FROM weight_entries WHERE entryId = :entryId AND userId = :userId LIMIT 1")
    WeightEntryEntity findById(long entryId, long userId);

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY date DESC, entryId DESC")
    List<WeightEntryEntity> findForUser(long userId);

    @Query("UPDATE weight_entries SET userId = :userId WHERE userId IS NULL")
    int assignLegacyEntries(long userId);
}
