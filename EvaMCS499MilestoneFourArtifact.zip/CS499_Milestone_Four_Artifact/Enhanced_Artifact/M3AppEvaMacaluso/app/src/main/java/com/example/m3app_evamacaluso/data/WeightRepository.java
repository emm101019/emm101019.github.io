package com.example.m3app_evamacaluso.data;

import com.example.m3app_evamacaluso.DatabaseHelper;
import com.example.m3app_evamacaluso.database.AppDatabase;
import com.example.m3app_evamacaluso.database.WeightEntryDao;
import com.example.m3app_evamacaluso.database.WeightEntryEntity;
import com.example.m3app_evamacaluso.model.WeightEntry;

import java.util.ArrayList;
import java.util.List;

/** Provides validated, account-scoped weight history operations. */
public final class WeightRepository {
    private final AppDatabase database;
    private final WeightEntryDao dao;
    private final long userId;

    public WeightRepository(DatabaseHelper helper, long userId) {
        this.database = helper.database();
        this.dao = database.weightEntryDao();
        this.userId = userId;
    }

    public boolean add(String date, double weight) {
        if (!valid(date, weight) || userId < 0) return false;
        try {
            dao.insert(new WeightEntryEntity(userId, date, weight));
            return true;
        } catch (RuntimeException exception) {
            return false;
        }
    }

    public boolean update(long id, String date, double weight) {
        if (!valid(date, weight) || userId < 0) return false;
        WeightEntryEntity entry = dao.findById(id, userId);
        if (entry == null) return false;
        entry.date = date;
        entry.weight = weight;
        return dao.update(entry) > 0;
    }

    public boolean delete(long id) {
        return userId >= 0 && dao.delete(id, userId) > 0;
    }

    public WeightEntry get(long id) {
        WeightEntryEntity entry = userId < 0 ? null : dao.findById(id, userId);
        return entry == null ? null : toModel(entry);
    }

    public List<WeightEntry> getAll() {
        List<WeightEntry> result = new ArrayList<>();
        if (userId < 0) return result;
        for (WeightEntryEntity entry : dao.findForUser(userId)) result.add(toModel(entry));
        return result;
    }

    private static boolean valid(String date, double weight) {
        return date != null && date.matches("\\d{4}-\\d{2}-\\d{2}")
                && Double.isFinite(weight) && weight > 0;
    }

    private static WeightEntry toModel(WeightEntryEntity entry) {
        return new WeightEntry(entry.entryId, entry.date, entry.weight);
    }
}
