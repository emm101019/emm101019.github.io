package com.example.m3app_evamacaluso;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;

import android.content.Context;

import androidx.room.Room;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.m3app_evamacaluso.database.AppDatabase;
import com.example.m3app_evamacaluso.database.UserEntity;
import com.example.m3app_evamacaluso.database.WeightEntryEntity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class RoomDatabaseTest {
    private AppDatabase database;

    @Before
    public void setUp() {
        Context context = ApplicationProvider.getApplicationContext();
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase.class)
                .allowMainThreadQueries()
                .build();
    }

    @After
    public void tearDown() {
        database.close();
    }

    @Test
    public void weightEntriesAreStoredAndScopedToTheirUser() {
        long firstUser = database.userDao().insert(new UserEntity("first", "hash-one"));
        long secondUser = database.userDao().insert(new UserEntity("second", "hash-two"));
        WeightEntryEntity firstEntry = new WeightEntryEntity(firstUser, "2026-02-01", 160.5);
        long entryId = database.weightEntryDao().insert(firstEntry);

        assertEquals(1, database.weightEntryDao().findForUser(firstUser).size());
        assertEquals(0, database.weightEntryDao().findForUser(secondUser).size());
        assertEquals(160.5, database.weightEntryDao().findById(entryId, firstUser).weight, 0.001);
        assertNull(database.weightEntryDao().findById(entryId, secondUser));

        firstEntry.entryId = entryId;
        firstEntry.date = "2026-02-02";
        firstEntry.weight = 159.8;
        assertNotEquals(0, database.weightEntryDao().update(firstEntry));
        assertEquals("2026-02-02", database.weightEntryDao().findById(entryId, firstUser).date);
        assertEquals(1, database.weightEntryDao().delete(entryId, firstUser));
        assertEquals(0, database.weightEntryDao().findForUser(firstUser).size());
    }
}
