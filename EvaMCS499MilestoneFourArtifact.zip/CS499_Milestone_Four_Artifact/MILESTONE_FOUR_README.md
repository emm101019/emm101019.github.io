# CS 499 Milestone Four Database Enhancement

This package includes the Weight Tracker project before and after its enhancements.

- `Original_Artifact` contains the original CS 360 Android project.
- `Enhanced_Artifact` contains the updated project. It includes the software design, algorithms, and database enhancements.
- `ENHANCEMENT_THREE_README.md` summarizes the database changes and test location.

Open the enhanced project in Android Studio. The database test is an instrumented test and needs an emulator or Android device.
